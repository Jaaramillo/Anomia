<?php
session_start(); 

include 'includes/db.php';
include 'includes/functions.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $query = "SELECT * FROM users WHERE email='$email'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) > 0) {
        $token = generateToken();
        $query = "UPDATE users SET reset_token='$token', token_expiry=DATE_ADD(NOW(), INTERVAL 1 HOUR) WHERE email='$email'";
        mysqli_query($conn, $query);

        $reset_link = "http://yourdomain.com/reset_password.php?token=$token";
        $subject = "Restablece tu contraseña";
        $message = "Haz clic en el siguiente enlace para restablecer tu contraseña: $reset_link";

        if (sendEmail($email, $subject, $message)) {
            $_SESSION['message'] = "Se ha enviado un enlace de restablecimiento de contraseña a tu correo electrónico.";
        } else {
            $_SESSION['message'] = "Hubo un error al enviar el correo electrónico.";
        }
    } else {
        $_SESSION['message'] = "Ese correo no está registrado.";
    }

    header("Location: reset_password_form.php");
    exit();
}
?>
