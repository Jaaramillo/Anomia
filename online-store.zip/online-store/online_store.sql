CREATE DATABASE IF NOT EXISTS online_store;
USE online_store;

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) NOT NULL UNIQUE,
    username VARCHAR(255) NOT NULL,
    lastname VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    
);


CREATE TABLE products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    image VARCHAR(255) NOT NULL,
    country_of_origin VARCHAR(255),
    image1 VARCHAR(255) DEFAULT NULL,
    image2 VARCHAR(255) DEFAULT NULL,
    image3 VARCHAR(255) DEFAULT NULL,
    category VARCHAR(255) NOT NULL,
    image_ VARCHAR(255) DEFAULT NULL,
    stock INT DEFAULT 0
);


INSERT INTO products (name, description, price, image, country_of_origin, image1, image2, image3, category, image_, stock) VALUES
('Camiseta Azul', 'Camiseta de algodón azul', 19.99, '/online-store/images/product1.jpg','China','/product1_2.jpg','/product1_2.jpg','/product1_2.jpg','Camisetas','/product1.jpg/', 50),
('Paco Rabanne', '1 Million Eau de Toillete', 49.99, '/online-store/images/product2.jpg', 'India','/product1_2.jpg','/product1_2.jpg','/product1_2.jpg', 'Perfumes','/product1.jpg/', 30),
('Paco Rabanne', 'Phantom Eau de Toillete ', 49.99, '/online-store/images/product3.jpg', 'India','/product1_2.jpg','/product1_2.jpg','/product1_2.jpg', 'Perfumes','/product1.jpg/', 20),
('Jean Paul Gaultier', 'Le Beau EDT ', 69.99, '/online-store/images/product4.jpg', 'India','/product1_2.jpg','/product1_2.jpg','/product1_2.jpg', 'Perfumes','/product1.jpg/', 15),
('Jean Paul Gaultier', 'Le Male Elixir', 69.99, '/online-store/images/product5.jpg', 'India','/product1_2.jpg','/product1_2.jpg','/product1_2.jpg', 'Perfumes','/product1.jpg/', 40),
('Zapatos Deportivos', 'Zapatos deportivos blancos,', 59.99, '/online-store/images/product6.jpg', 'India','/product1_2.jpg','/product1_2.jpg','/product1_2.jpg', 'Zapatos','/product1.jpg/', 25),
('Bolso de mano', 'Bolso de mano, piel sintetica', 145.99, '/online-store/images/product7.jpg', 'India', '/product1_2.jpg','/product1_2.jpg','/product1_2.jpg','Accesorios','/product1.jpg/', 70),
('Pantalón', 'Pantalón Jagger beige ', 79.99, '/online-store/images/product8.jpg', 'India','/product1_2.jpg','/product1_2.jpg','/product1_2.jpg', 'Bolsos','/product1.jpg/', 10),
('Cinturón de Cuero', 'Cinturón de cuero negro', 24.99, '/online-store/images/product9.jpg', 'India', '/product1_2.jpg','/product1_2.jpg','/product1_2.jpg','Accesorios','/product1.jpg/', 35),
('Gafas de Sol', 'Gafas de sol polarizadas', 29.99, '/online-store/images/product10.jpg', 'India','/product1_2.jpg','/product1_2.jpg','/product1_2.jpg', 'Accesorios','/product1.jpg/', 50),
('Reloj de Pulsera', 'Reloj de pulsera con correa de cuero', 89.99, '/online-store/images/product11.jpg', 'India','/product1_2.jpg','/product1_2.jpg','/online-store/images/product1.jpg', 'Relojes','/product1.jpg/', 20),
('Guantes de Invierno', 'Guantes de lana ', 19.99, '/online-store/images/product12.jpg', 'India','/product1_2.jpg','/product1_2.jpg','/product1_2.jpg', 'Accesorios','/product1.jpg/', 40);


CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    address VARCHAR(255) NOT NULL,
    email VARCHAR(100) NOT NULL,
    total DECIMAL(10, 2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id),
    FOREIGN KEY (product_id) REFERENCES products(id)
);
