document.addEventListener('DOMContentLoaded', () => {
    console.log('JavaScript cargado correctamente.');
});

document.addEventListener("DOMContentLoaded", function() {
    const form = document.querySelector("form");
    form.addEventListener("submit", function(event) {
        const password = document.querySelector("#password").value;
        if (password.length < 8) {
            alert("La contraseña debe tener al menos 8 caracteres.");
            event.preventDefault();
        }
    });
});
