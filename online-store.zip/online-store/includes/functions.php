<?php

/**
 * Envía un correo electrónico utilizando la función mail de PHP.
 *
 * @param string $to Correo electrónico del destinatario.
 * @param string $subject Asunto del correo.
 * @param string $message Cuerpo del correo.
 * @param string $headers Encabezados del correo.
 * @return bool true en caso de éxito, false en caso de error.
 */
function sendEmail($to, $subject, $message, $headers = 'From: no-reply@yourdomain.com') {
    return mail($to, $subject, $message, $headers);
}

/**
 * Genera un token seguro.
 *
 * @param int $length Longitud del token en bytes.
 * @return string Token generado en hexadecimal.
 */
function generateToken($length = 50) {
    return bin2hex(random_bytes($length));
}
