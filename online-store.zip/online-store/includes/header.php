<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tienda en Línea</title>
    <link rel="stylesheet" href="/online-store/css/styles.css">
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
        }

        header {
            color: white;
            padding: 15px 25px; 
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        header h1 {
            margin: 0;
            font-size: 2em;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        nav ul {
            list-style: none;
            margin: 0;
            padding: 0;
            display: flex;
            align-items: center;
        }

        nav ul li {
            margin: 0 12px; 
            position: relative;
        }

        nav ul li a {
            text-decoration: none;
            color: white;
            font-weight: bold;
            padding: 12px 18px; 
            border-radius: 5px;
            transition: background-color 0.3s, color 0.3s;
        }

        nav ul li a:hover {
            background-color: #575757;
            color: #fff;
        }

        .header-logo {
            display: flex;
            align-items: center;
            max-width: 60%;
        }

        .header-logo img {
            max-height: 50px; 
            margin-right: 12px;
        }


        .dropdown {
            cursor: pointer;
        }

        .dropdown-menu {
            display: none;
            position: absolute;
            top: 100%;
            left: 0;
            background-color: #333;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 5px;
            overflow: hidden;
            z-index: 1000;
        }

        .dropdown-menu a {
            display: block;
            padding: 12px 20px;
            white-space: nowrap;
            color: white;
            text-decoration: none;
        }

        .dropdown-menu a:hover {
            background-color: #575757;
        }

        .dropdown:hover .dropdown-menu {
            display: block;
        }
    </style>
</head>
<body>
<header>
    <div class="header-logo">
        <img src="/online-store/images/logo.png" alt="Logo de Anomia">
        <h1>Anomia</h1>
    </div>
    <nav>
        <ul>
            <li><a href="/online-store/index.php">Inicio</a></li>
            <li><a href="/online-store/pages/products.php">Catálogo</a></li>
            <li><a href="/online-store/login.php">Login</a></li>
            <li><a href="/online-store/pages/cart.php">Carrito</a></li>
            <li><a href="/online-store/myaccount.php">Mi cuenta</a></li>
            <li><a href="/online-store/logout.php">Cerrar sesión</a></li>
            <li class="dropdown">
                <a href="#">Más</a>
                <div class="dropdown-menu">
                    <a href="/online-store/pages/about_us.php">Sobre Nosotros</a>
                    <a href="/online-store/pages/our_story.php">Nuestra Historia</a>
                </div>
            </li>
        </ul>
    </nav>
</header>
<main>
