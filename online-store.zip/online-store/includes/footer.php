<footer>
    <style>
        footer {
            background-color: #333;
            color: white;
            padding: 15px 20px;
            text-align: center;
            font-size: 0.9em;
            box-shadow: 0 -4px 8px rgba(0, 0, 0, 0.1);
            position: relative;
            bottom: 0;
            width: 100%;
        }
        footer a {
            color: #fff;
            text-decoration: none;
            margin: 0 10px;
            font-weight: bold;
        }
        footer a:hover {
            text-decoration: underline;
        }
    </style>
    <p>&copy; 2024 Tienda en línea. Todos los derechos reservados.</p>
    <p>
        <a href="/online-store/privacy-policy.php">Política de Privacidad</a> |
        <a href="/online-store/terms.php">Términos y Condiciones</a> |
        <a href="/online-store/contact.php">Contacto</a>
    </p>
</footer>
</body>
</html>
