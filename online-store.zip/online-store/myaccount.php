<?php

session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include 'includes/db.php'; 

$user_id = $_SESSION['user_id'];
$query = "SELECT * FROM users WHERE id = $user_id";
$result = mysqli_query($conn, $query);
$user = mysqli_fetch_assoc($result);

include 'includes/header.php'; 

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Mi cuenta</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <main>
        <form action="update_account.php" method="POST" enctype="multipart/form-data">
            <label for="username">Nombre de usuario:</label>
            <input type="text" id="username" name="username" value="<?php echo $user['username']; ?>" required>

            <label for="lastname">Apellidos de usuario:</label>
            <input type="text" id="lastname" name="lastname" value="<?php echo $user['lastname']; ?>" required>
            
            <label for="email">Correo electrónico:</label>
            <input type="email" id="email" name="email" value="<?php echo $user['email']; ?>" required>
            
            <label for="profile_pic">Foto de perfil:</label>
            <input type="file" id="profile_pic" name="profile_pic">
            
            <button type="submit">Actualizar</button>
        </form>
    </main>

</body>
<?php include 'includes/footer.php'; ?>

</html>


