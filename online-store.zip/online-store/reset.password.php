<?php include('includes/header.php'); ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Restablecer contraseña</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <h2>Restablecer contraseña</h2>
    <form method="POST" action="update_password.php">
        <input type="hidden" name="token" value="<?php echo htmlspecialchars($_GET['token']); ?>">
        <label for="new_password">Nueva contraseña:</label>
        <input type="password" id="new_password" name="new_password" required>
        <label for="confirm_password">Confirma tu nueva contraseña:</label>
        <input type="password" id="confirm_password" name="confirm_password" required>
        <button type="submit">Restablecer contraseña</button>
    </form>
    <p><a href="login.php">Volver al inicio de sesión</a></p>
<?php include('includes/footer.php'); ?>
</body>
</html>
