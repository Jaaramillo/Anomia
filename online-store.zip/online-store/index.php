<?php include 'includes/header.php'; ?>

<section class="hero">
    <img src="/online-store/images/hero.jpg" alt="Imagen de fondo" class="hero-img">
    <div class="hero-content">
        <h1>Bienvenidos a Anomia</h1>
        <p>Encuentra las mejores novedades aquí</p>
    </div>
</section>

<section class="products-section">
    <h2>Nuestros Productos</h2>
    <h3>Compra aquí</h3>
    <ul class="product-list">
        <?php
        include 'includes/db.php';
        $sql = "SELECT * FROM products";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<li class='product-item'>";
                echo "<a href='pages/product_detail.php?id=" . $row["id"] . "' class='product-link'>";
                echo "<img src='" . $row["image"] . "' alt='" . $row["name"] . "' class='product-image'>";
                echo "<h3 class='product-name'>" . $row["name"] . "</h3>";
                echo "</a>";
                echo "</li>";
            }
        } else {
            echo "<p>No hay productos disponibles.</p>";
        }

        $conn->close();
        ?>
    </ul>
</section>

<?php include 'includes/footer.php'; ?>

<style>
.hero {
    position: relative;
    text-align: center;
    color: white;
}

.hero-img {
    width: 100%;
    height: auto;
}

.hero-content {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
}

.products-section {
    padding: 20px;
    text-align: center;
}

.product-list {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    list-style: none;
    padding: 0;
}

.product-item {
    flex: 1 1 calc(25% - 20px);
    margin: 10px;
    border: 1px solid #ddd;
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    overflow: hidden;
    transition: transform 0.2s;
}

.product-item:hover {
    transform: scale(1.05);
}

.product-link {
    text-decoration: none;
    color: inherit;
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 20px;
}

.product-image {
    max-width: 100%;
    height: auto;
    border-bottom: 1px solid #ddd;
}

.product-name {
    margin: 15px 0 10px;
    font-size: 1.1em;
    color: #333;
}
</style>
