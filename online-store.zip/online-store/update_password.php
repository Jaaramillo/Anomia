<?php
include 'includes/db.php';
include 'includes/functions.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $token = mysqli_real_escape_string($conn, $_POST['token']);
    $new_password = mysqli_real_escape_string($conn, $_POST['new_password']);
    $confirm_password = mysqli_real_escape_string($conn, $_POST['confirm_password']);

    if ($new_password === $confirm_password) {
        $hashed_password = password_hash($new_password, PASSWORD_BCRYPT);
        $user = verifyToken($conn, $token);

        if ($user) {
            $query = "UPDATE users SET password='$hashed_password', reset_token=NULL, token_expiry=NULL WHERE id={$user['id']}";
            mysqli_query($conn, $query);
            echo "Tu contraseña ha sido restablecida correctamente.";
        } else {
            echo "El token de restablecimiento es inválido o ha expirado.";
        }
    } else {
        echo "Las contraseñas no coinciden.";
    }
}
?>
