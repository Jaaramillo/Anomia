<?php
session_start(); 

include('includes/header.php');

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Restablecer Contraseña</title>
    <link rel="stylesheet" href="css/styles.css">
    <style>
       
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
        }
        .reset-container {
            background-color: white;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 470px;
        }
        .reset-container h2 {
            text-align: center;
            margin-bottom: 20px;
            font-size: 28px;
            color: #333;
        }
        .reset-container form {
            display: flex;
            flex-direction: column;
        }
        .reset-container label {
            margin-bottom: 8px;
            font-weight: bold;
            color: #333;
        }
        .reset-container input[type="email"] {
            padding: 12px;
            margin-bottom: 20px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }
        .reset-container button[type="submit"] {
            padding: 12px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 18px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .reset-container button[type="submit"]:hover {
            background-color: #0056b3;
        }
        .reset-container p {
            text-align: center;
            margin-top: 20px;
            font-size: 16px;
            color: #666;
        }
        .reset-container p a {
            color: #007bff;
            text-decoration: none;
            font-weight: bold;
            transition: color 0.3s ease;
        }
        .reset-container p a:hover {
            color: #0056b3;
        }
        .error-message {
            color: red;
            text-align: center;
            margin-bottom: 15px;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="reset-container">
        <h2>Restablecer Contraseña</h2>

        <?php
        
        if (isset($_SESSION['message'])) {
            echo "<p class='error-message'>" . $_SESSION['message'] . "</p>";
           
            unset($_SESSION['message']);
        }
        ?>

        <form method="POST" action="send_reset_email.php">
            <label for="email">Correo Electrónico:</label>
            <input type="email" id="email" name="email" required>
            <button type="submit">Enviar</button>
        </form>

        <p><a href="login.php">Volver al inicio de sesión</a></p>
    </div>

    <?php include('includes/footer.php'); ?>
</body>
</html>
