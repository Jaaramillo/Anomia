<?php
include '../includes/header.php';
include '../includes/db.php';

if (isset($_GET['id'])) {
    $product_id = intval($_GET['id']); 
    $sql = "SELECT * FROM products WHERE id = $product_id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $product = $result->fetch_assoc();
    } else {
        echo "<p>Producto no encontrado.</p>";
        include '../includes/footer.php';
        exit();
    }
} else {
    echo "<p>ID de producto no especificado.</p>";
    include '../includes/footer.php';
    exit();
}
?>

<style>
.product-view {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    max-width: 800px;
    margin: 20px auto;
    padding: 20px;
    border: 1px solid #ddd;
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    background-color: #fff;
}

.image-gallery {
    flex: 1;
    display: flex;
    flex-direction: column;
    align-items: center;
    margin-right: 20px;
}

#main-image {
    max-width: 100%;
    height: auto;
    border-radius: 10px;
    margin-bottom: 10px;
}

.thumbnails {
    display: flex;
    justify-content: center;
}

.thumbnails img {
    width: 80px;
    height: 80px;
    margin: 0 5px;
    border: 2px solid transparent;
    border-radius: 5px;
    cursor: pointer;
    transition: border 0.3s;
}

.thumbnails img:hover {
    border: 2px solid #007bff;
}

.product-details {
    flex: 1;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    text-align: left;
}

.product-details h2 {
    margin-bottom: 20px;
}

.product-details p,
.product-details label {
    margin: 10px 0;
}

.product-details select,
.product-details input {
    width: 100%;
    padding: 10px;
    margin-top: 5px;
    border: 1px solid #ddd;
    border-radius: 5px;
}

.product-details button {
    width: 100%;
    padding: 15px;
    margin-top: 20px;
    border: none;
    border-radius: 5px;
    background-color: #28a745;
    color: white;
    font-size: 16px;
    cursor: pointer;
}

.product-details button:hover {
    opacity: 0.9;
}
</style>

<div class="product-view">
    <div class="image-gallery">
        <img id="main-image" src="../images/<?php echo htmlspecialchars($product['image2']); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>">
        <div class="thumbnails">
            <img src="../images/<?php echo htmlspecialchars($product['image2']); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>" onclick="changeImage(this.src)">
            <?php if (!empty($product['image1'])): ?>
                <img src="../images/<?php echo htmlspecialchars($product['image1']); ?>" alt="Vista Alternativa 1" onclick="changeImage(this.src)">
            <?php endif; ?>
            <?php if (!empty($product['image2'])): ?>
                <img src="../images/<?php echo htmlspecialchars($product['image2']); ?>" alt="Vista Alternativa 2" onclick="changeImage(this.src)">
            <?php endif; ?>
            <?php if (!empty($product['image3'])): ?>
                <img src="../images/<?php echo htmlspecialchars($product['image3']); ?>" alt="Vista Alternativa 3" onclick="changeImage(this.src)">
            <?php endif; ?>
        </div>
    </div>
    <div class="product-details">
        <h2><?php echo htmlspecialchars($product['name']); ?></h2>
        <p>País de origen: <?php echo htmlspecialchars($product['country_of_origin']); ?></p>
        <label for="size">Tallas disponibles:</label>
        <select id="size" name="size">
            <option value="XS">XS</option>
            <option value="S">S</option>
            <option value="M">M</option>
            <option value="L">L</option>
            <option value="XL">XL</option>
        </select>
        <label for="quantity">Cantidad:</label>
        <input type="number" id="quantity" name="quantity" min="1" max="<?php echo htmlspecialchars($product['stock']); ?>" value="1">
        <p>Precio: $<span id="price"><?php echo htmlspecialchars($product['price']); ?></span></p>
    </div>
</div>

<script>
function changeImage(src) {
    document.getElementById('main-image').src = src;
}
</script>

<?php include '../includes/footer.php'; ?>
