<?php include '../includes/header.php'; ?>

<section class="cart-section">
    <h2>Carrito de Compras</h2>
    <div class="cart-container">
        <ul class="cart-list" id="cart-list"></ul>
        <div class="cart-summary">
            <p>Total: $<span id="total-price">0.00</span></p>
            <button onclick="clearCart()">Vaciar Carrito</button>
            <button onclick="checkout()">Proceder al Pago</button>
        </div>
    </div>
</section>

<script>
function loadCart() {
    let cart = JSON.parse(localStorage.getItem('cart')) || [];
    let cartList = document.getElementById('cart-list');
    let totalPrice = 0;
    cartList.innerHTML = '';

    cart.forEach(product => {
        let listItem = document.createElement('li');
        listItem.classList.add('cart-item');
        listItem.innerHTML = `
            <div class="cart-item-image">
                <img src="${product.image}" alt="${product.name}">
            </div>
            <div class="cart-item-details">
                <h3>${product.name}</h3>
                <p>${product.description}</p>
                <p><strong>Talla:</strong> ${product.size}</p>
                <p><strong>Cantidad:</strong> ${product.quantity}</p>
                <p><strong>Precio Unitario:</strong> $${product.price.toFixed(2)}</p>
                <p><strong>Subtotal:</strong> $${(product.price * product.quantity).toFixed(2)}</p>
            </div>
        `;
        cartList.appendChild(listItem);
        totalPrice += product.price * product.quantity;
    });

    document.getElementById('total-price').textContent = totalPrice.toFixed(2);
}

function clearCart() {
    localStorage.removeItem('cart');
    loadCart();
    alert("Carrito vaciado");
}

function checkout() {
    let cart = JSON.parse(localStorage.getItem('cart'));
    if (cart && cart.length > 0) {
        window.location.href = 'checkout.php';
    } else {
        alert("El carrito está vacío.");
    }
}

window.onload = loadCart;
</script>

<style>
    .cart-section {
        padding: 20px;
        max-width: 800px;
        margin: 0 auto;
        background-color: #f9f9f9;
        border-radius: 8px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    .cart-container {
        display: flex;
        flex-direction: column;
    }

    .cart-list {
        list-style-type: none;
        padding: 0;
        margin: 0 0 20px 0;
    }

    .cart-item {
        display: flex;
        align-items: center;
        border-bottom: 1px solid #ddd;
        padding: 15px 0;
    }

    .cart-item-image img {
        width: 80px;
        height: 80px;
        border-radius: 5px;
        object-fit: cover;
        margin-right: 20px;
    }

    .cart-item-details {
        flex: 1;
    }

    .cart-item-details h3 {
        margin: 0 0 10px;
    }

    .cart-item-details p {
        margin: 5px 0;
    }

    .cart-summary {
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .cart-summary p {
        font-size: 1.2em;
        font-weight: bold;
    }

    .cart-summary button {
        padding: 10px 20px;
        background-color: #007bff;
        border: none;
        border-radius: 5px;
        color: white;
        font-size: 1em;
        cursor: pointer;
        margin-left: 10px;
    }

    .cart-summary button:hover {
        background-color: #0056b3;
    }
</style>

<?php include '../includes/footer.php'; ?>
