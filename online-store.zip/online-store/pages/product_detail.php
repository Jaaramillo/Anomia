<?php
include '../includes/header.php';
include '../includes/db.php';

if (isset($_GET['id'])) {
    $product_id = $_GET['id'];
    $stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
    } else {
        echo "<p>Producto no encontrado.</p>";
        include '../includes/footer.php';
        exit();
    }
    $stmt->close();
} else {
    echo "<p>ID de producto no especificado.</p>";
    include '../includes/footer.php';
    exit();
}
?>

<style>
/* General Styles */
body {
    font-family: 'Arial', sans-serif;
    color: #333;
    background-color: #f8f9fa;
    margin: 0;
    padding: 0;
}

section.product-detail {
    max-width: 800px;
    margin: 20px auto;
    padding: 20px;
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    border: 1px solid #ddd;
}

.product-detail img {
    width: 100%;
    height: auto;
    border-radius: 8px;
    object-fit: cover;
}

.product-detail h2 {
    font-size: 2rem;
    margin: 15px 0;
    color: #333;
}

.product-detail p {
    font-size: 1rem;
    margin: 10px 0;
    color: #666;
}

.product-detail label {
    font-weight: bold;
    margin-top: 15px;
    display: block;
}

.product-detail input,
.product-detail select {
    width: 100%;
    padding: 12px;
    margin-top: 5px;
    border: 1px solid #ccc;
    border-radius: 5px;
    box-sizing: border-box;
}

.product-detail button {
    width: 100%;
    padding: 14px;
    margin-top: 20px;
    border: none;
    border-radius: 5px;
    font-size: 16px;
    color: #fff;
    cursor: pointer;
    transition: background-color 0.3s, transform 0.2s;
}

.product-detail button:nth-child(2) {
    background-color: #007bff;
}

.product-detail button:nth-child(3) {
    background-color: #28a745;
}

.product-detail button:hover {
    opacity: 0.9;
    transform: scale(1.02);
}

.product-detail button:active {
    transform: scale(0.98);
}

@media (max-width: 768px) {
    section.product-detail {
        padding: 15px;
        margin: 10px;
    }

    .product-detail h2 {
        font-size: 1.5rem;
    }
}
</style>

<section class="product-detail">
    <img id="product-image" src="<?php echo htmlspecialchars($row['image']); ?>" alt="<?php echo htmlspecialchars($row['name']); ?>" width="600" height="400">
    <h2 id="product-name"><?php echo htmlspecialchars($row['name']); ?></h2>
    <p id="product-description"><?php echo htmlspecialchars($row['description']); ?></p>
    <p id="product-price" data-price="<?php echo $row['price']; ?>">Precio: $<?php echo $row['price']; ?></p>
    <p id="product-category">Categoría: <?php echo htmlspecialchars($row['category']); ?></p>
    <p id="product-stock">Stock disponible: <?php echo $row['stock']; ?></p>
    <label for="quantity">Cantidad:</label>
    <input type="number" id="quantity" name="quantity" min="1" max="<?php echo $row['stock']; ?>" value="1">
    <label for="size">Talla:</label>
    <select id="size" name="size">
        <option value="XS">XS</option>
        <option value="S">S</option>
        <option value="M">M</option>
        <option value="L">L</option>
        <option value="XL">XL</option>
    </select>
    <button onclick="addToCart()">Añadir al Carrito</button>
    <button onclick="buyNow()">Comprar Ahora</button>
</section>

<script>
function addToCart() {
    const quantity = parseInt(document.getElementById('quantity').value);
    const maxQuantity = parseInt(document.getElementById('quantity').max);

    if (quantity > maxQuantity || quantity <= 0) {
        alert("Cantidad no válida.");
        return;
    }

    const product = {
        id: <?php echo $row['id']; ?>,
        name: document.getElementById('product-name').innerText,
        description: document.getElementById('product-description').innerText,
        image: document.getElementById('product-image').src,
        price: parseFloat(document.getElementById('product-price').getAttribute('data-price')),
        quantity: quantity,
        size: document.getElementById('size').value
    };

    let cart = JSON.parse(localStorage.getItem('cart')) || [];
    const existingProduct = cart.find(item => item.id === product.id && item.size === product.size);

    if (existingProduct) {
        existingProduct.quantity += product.quantity;
    } else {
        cart.push(product);
    }

    localStorage.setItem('cart', JSON.stringify(cart));
    alert("Producto añadido al carrito");
}

function buyNow() {
    addToCart();
    window.location.href = 'checkout.php';
}
</script>

<?php include '../includes/footer.php'; ?>
