<?php include '../includes/header.php'; ?>
<?php include '../includes/db.php'; ?>

<section class="checkout-section">
    <div class="container">
        <h2>Checkout</h2>
        <form id="checkout-form" action="checkout.php" method="post">
            <div class="form-group">
                <label for="name">Nombre Completo:</label>
                <input type="text" id="name" name="name" required>
            </div>
            <div class="form-group">
                <label for="address">Dirección:</label>
                <input type="text" id="address" name="address" required>
            </div>
            <div class="form-group">
                <label for="email">Correo Electrónico:</label>
                <input type="email" id="email" name="email" required>
            </div>
            <input type="hidden" id="cart" name="cart">
            <button type="submit" class="button">Realizar Compra</button>
        </form>
    </div>
</section>

<script>
const cart = JSON.parse(localStorage.getItem('cart')) || [];
document.getElementById('cart').value = JSON.stringify(cart);

// Limpiar el carrito después de la compra
document.getElementById('checkout-form').addEventListener('submit', () => {
    localStorage.removeItem('cart');
});
</script>

<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $address = $_POST['address'];
    $email = $_POST['email'];
    $cart = json_decode($_POST['cart'], true);

    $sql = "INSERT INTO orders (name, address, email, total) VALUES ('$name', '$address', '$email', 0)";
    if ($conn->query($sql) === TRUE) {
        $order_id = $conn->insert_id;
        $total = 0;
        foreach ($cart as $product) {
            $product_id = $product['id'];
            $quantity = 1; // You can extend this to allow quantity
            $price = $product['price'];
            $total += $price * $quantity;
            $conn->query("INSERT INTO order_items (order_id, product_id, quantity, price) VALUES ('$order_id', '$product_id', '$quantity', '$price')");
        }
        $conn->query("UPDATE orders SET total='$total' WHERE id='$order_id'");
        echo "<div class='container'><p class='success-message'>Compra realizada con éxito.</p></div>";
    } else {
        echo "<div class='container'><p class='error-message'>Error: " . $sql . "<br>" . $conn->error . "</p></div>";
    }
    $conn->close();
}
?>

<?php include '../includes/footer.php'; ?>
