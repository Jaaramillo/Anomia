<?php include '../includes/header.php'; ?>
<?php include '../includes/db.php'; ?>

<div class="product-list">
    <?php
    $sql = "SELECT id, name, price, image1 FROM products";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo "<div class='product'>";
            echo "<img src='../images/" . $row['image1'] . "' alt='" . $row['name'] . "'>";
            echo "<h3>" . $row['name'] . "</h3>";
            echo "<p>Precio: $" . $row['price'] . "</p>";
            echo "<button onclick=\"location.href='../pages/products_view.php?id=" . $row['id'] . "'\">Visualizar</button>";
            echo "</div>";
        }
    } else {
        echo "<p>No hay productos disponibles.</p>";
    }
    ?>
</div>

<?php include '../includes/footer.php'; ?>
